use crate::render_node::RenderNode;
use crate::resource_manager::ResourceManager;

pub trait RenderContext{
    fn setup(&mut self, resource_manager: &mut ResourceManager);
    fn render(&mut self, render_node: &RenderNode);
}