mod instance;
mod material;
mod sprite;
mod transform;
mod vertex;
mod mesh;
mod texture;


/// Trait for converting a type to a byte slice.
pub trait AsBytes {
    fn as_bytes(&self) -> &[u8];
}