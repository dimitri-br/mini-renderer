use crate::types::texture::Texture;

pub struct Material{
    // Texture
    diffuse_texture: Texture
}
