pub struct RenderNode{
    name: String,
    // The name of the node

    inputs: Vec<String>,
    // The names of the nodes that this node depends on

    outputs: Vec<String>,
    // The names of the nodes that depend on this node

    dependencies: Vec<String>,

    execute: Box<dyn Fn(&mut RenderContext)>,
    // The function that executes the node

    dirty: bool,
    // Whether the node needs to be re-executed
}