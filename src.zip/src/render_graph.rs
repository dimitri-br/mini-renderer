use crate::render_node::RenderNode;

pub struct RenderGraph{
    nodes: Vec<RenderNode>
}