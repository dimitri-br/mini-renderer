use std::collections::HashMap;
use log::error;
use wgpu::StoreOp;
use winit::event::{Event, WindowEvent};
use crate::device_handle::DeviceHandle;
use crate::handle::Handle;
use crate::instance_handle::InstanceHandle;
use crate::surface_wrapper::SurfaceWrapper;

use winit::window::{Window, WindowBuilder};
use winit::event_loop::{ControlFlow, EventLoop};
use crate::pipeline::Pipeline;

type RenderHandle = usize;

pub struct Renderer{
    instance_handler: InstanceHandle,
    device_handle: DeviceHandle,
    surface_wrapper: SurfaceWrapper,

    window: Handle<Window>,
    event_loop: Option<EventLoop<()>>
}

impl Renderer{
    pub fn new() -> Self{
        env_logger::builder()
            .filter_level(log::LevelFilter::Info)
            // We keep wgpu at Error level, as it's very noisy.
            .filter_module("wgpu_core", log::LevelFilter::Info)
            .filter_module("wgpu_hal", log::LevelFilter::Error)
            .filter_module("naga", log::LevelFilter::Error)
            .parse_default_env()
            .init();

        let event_loop = EventLoop::new().unwrap_or_else(
            |e| {
                error!("Failed to create event loop: {}", e);
                panic!("Failed to create event loop: {}", e)
            }
        );

        let window = WindowBuilder::new()
            .with_title("Renderer")
            .build(&event_loop).unwrap_or_else(
                |e| {
                    error!("Failed to create window: {}", e);
                    panic!("Failed to create window: {}", e)
                }
            );
        let window = Handle::new(window);

        let instance_handler = InstanceHandle::new();
        let device_handle = DeviceHandle::new(&instance_handler);

        let surface_wrapper = SurfaceWrapper::new(&instance_handler, &device_handle, window.clone());


        Self{
            instance_handler,
            device_handle,
            surface_wrapper,

            window,
            event_loop: Some(event_loop)
        }
    }

    pub(crate) fn render(&mut self){
        // Get the current frame from the surface
        let frame = self.surface_wrapper.get_surface().get().get_current_texture()
            .unwrap_or_else(|e| {
                error!("Failed to get current frame: {}", e);
                panic!("Failed to get current frame: {}", e)
            }
        );

        let output = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());

        let mut encoder = self.device_handle.get_device().get().create_command_encoder(
            &wgpu::CommandEncoderDescriptor{
                label: Some("Render Encoder")
            }
        );

        {
            let _render_pass = encoder.begin_render_pass(
                &wgpu::RenderPassDescriptor{
                    label: Some("Render Pass"),
                    color_attachments: &[
                        Some(wgpu::RenderPassColorAttachment{
                            view: &output,
                            resolve_target: None,
                            ops: wgpu::Operations{
                                load: wgpu::LoadOp::Clear(wgpu::Color::WHITE),
                                store: StoreOp::Store
                            }
                        })
                    ],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                }
            );
        }

        self.device_handle.get_queue().get().submit(std::iter::once(encoder.finish()));

        frame.present();
    }

    pub fn run(mut self){
        let event_loop = self.event_loop.take().unwrap();
        // Run the event loop, without blocking the current thread
        event_loop.run(move |event, target| {
            target.set_control_flow(ControlFlow::Poll);

            match event{
                Event::AboutToWait{..} => {
                    self.window.get().request_redraw();
                }
                Event::WindowEvent{
                    event,
                    window_id
                } => {
                    if window_id == self.window.get().id(){
                        match event{
                            WindowEvent::CloseRequested => {
                                target.exit();
                            }
                            WindowEvent::Resized(new_size) => {
                                self.surface_wrapper.resize_surface(
                                    self.device_handle.get_device().get(),
                                    new_size
                                );
                                self.window.get().request_redraw();
                            }
                            WindowEvent::RedrawRequested => {
                                self.render();
                            }
                            _ => {}
                        }
                    }
                }
                _ => {}
            }
        }).expect("TODO: panic message");
    }
}

impl Default for Renderer{
    fn default() -> Self{
        Self::new()
    }
}
