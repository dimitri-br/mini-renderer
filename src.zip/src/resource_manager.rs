use std::collections::HashMap;
use crate::handle::Handle;

trait Resource{}

pub struct ResourceHandle<T>{
    resource: Handle<T>
}

pub struct ResourceManager{
    resources: HashMap<String, ResourceHandle<dyn Resource>>
}

impl ResourceManager{
    pub fn new() -> Self{
        Self{
            resources: HashMap::new()
        }
    }

    pub fn add_resource<T: Resource>(&mut self, name: &str, resource: T){
        self.resources.insert(name.to_string(), ResourceHandle{
            resource: Handle::new(resource)
        });
    }

    pub fn get_resource<T: Resource>(&self, name: &str) -> Option<ResourceHandle<T>>{
        self.resources.get(name).map(|resource| ResourceHandle{
            resource: resource.resource.clone()
        })
    }
}

